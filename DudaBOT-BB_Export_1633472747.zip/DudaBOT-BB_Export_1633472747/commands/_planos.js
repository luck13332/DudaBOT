/*CMD
  command: /planos
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: plano, plano, planos, planos, /plano, /planos, planos, /planos
CMD*/

Bot.sendKeyboard("🇺🇲 𝗕𝗮‌𝘀𝗶𝗰𝗼 - R$4.00 / Vinculação de Código,\n,🇧🇷 𝗜𝗻𝗶𝗰𝗶𝗮𝗻𝘁𝗲 - R$6.50 / Vinculação de Código+Login (G-mail),\n,🇲🇫 𝗜𝗻𝘁𝗲𝗿𝗺𝗲𝗱𝗶𝗮‌𝗿𝗶𝗼 - R$7.00 / Vinculação de Código+Login (Telefone),\n,🇬🇧 𝗔𝘃𝗮𝗻𝗰‌𝗮𝗱𝗼 - R$10.50 / 2 Vinculações de Código+Login (G-mail),\n,🇯🇵 𝗘𝗺𝗽𝗿𝗲𝘀𝗮𝗿𝗶𝗮𝗹 - R$14.00 / 2 Vinculações de Código+Login (Telefone),\n,📋 Home Screen" , "_Selecione o seu Plano_")
Bot.runCommand("/todosplanos")
