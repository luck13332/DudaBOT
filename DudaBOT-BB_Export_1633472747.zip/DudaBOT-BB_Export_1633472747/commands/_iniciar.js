/*CMD
  command: /iniciar
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER
Olá, eu sou a *DUDA*. Uma robô automatizado da equipe *WolkTeen Dev*. Fui criada para gerenciar as vendas/suportes da equipe 🤖

Digite /planos para *ver e comprar os planos disponíveis* ✅

Digite /comprovantes para enviar *prova de pagamentos* 🧾

Digite /suporte para enviar *mensagem de apoio* 🗣️

_Versão do BOT_: *1.0*
_Última Atualização_: *05/10/2021 às 19:54 Brasília*
  ANSWER
  keyboard: 
  aliases: oi, oi, olá, ola, ola, ola, iniciar, iniciar, /iniciar
CMD*/

